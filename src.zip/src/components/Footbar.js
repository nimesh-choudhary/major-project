import React from "react";
import "./css/Footbar.css";

function Footbar(){
    return(
        <header className="footbar">
            <div className="copyright">
                <h1>@ 2022 Copyright | Developed by ______</h1>
            </div>

        </header>
    )
}

export default Footbar;