import React from "react";

function Login(){
    return(
        <div>
            <input placeholder="enter"/>
        </div>
    )
}
export default Login;