import React from "react";
import "./css/Driver.css";
import Footbar from "./Footbar";
import Nav from "./Nav";
// import "./College.css";


const data = [
    {sno: "1", drivername: "Driver XYZ",}
]

function Driver(){
    return(
        <div>
        <Nav/>
            <div>
                <div className="box">
                    <div className="driver-box">
                        <div className="color-box"></div>
                        <h1 className="driver-text">Find Driver</h1>
                        <div className="campus-box">
                            
                        </div>
                    </div>
                </div>
            </div>
        <Footbar/>
        </div>
    )
}
export default Driver;